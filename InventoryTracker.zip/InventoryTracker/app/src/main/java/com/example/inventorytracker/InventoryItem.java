package com.example.inventorytracker;

/**
 * Plain data holder for one row of the inventory table.
 */
public class InventoryItem {
    private final long id;
    private final String name;
    private final int quantity;
    private final int lowThreshold;

    public InventoryItem(long id, String name, int quantity, int lowThreshold) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.lowThreshold = lowThreshold;
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public int getLowThreshold() { return lowThreshold; }

    /** An item is "low" once its quantity reaches its own alert level. */
    public boolean isLow() {
        return quantity <= lowThreshold;
    }
}
