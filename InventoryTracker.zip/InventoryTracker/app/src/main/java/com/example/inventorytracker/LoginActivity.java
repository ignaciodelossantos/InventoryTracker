package com.example.inventorytracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * First screen. Existing users log in; new users create an account here too.
 */
public class LoginActivity extends AppCompatActivity {

    public static final String EXTRA_USER_ID = "user_id";

    // Digits, plus sign, spaces, dashes and brackets, between 3 and 20 characters.
    private static final String PHONE_PATTERN = "[+0-9() -]{3,20}";

    private EditText editUsername;
    private EditText editPassword;
    private EditText editPhone;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        editPhone = findViewById(R.id.editPhone);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreate = findViewById(R.id.buttonCreateAccount);
        CheckBox checkShowPassword = findViewById(R.id.checkShowPassword);

        buttonLogin.setOnClickListener(v -> handleLogin());
        buttonCreate.setOnClickListener(v -> handleCreateAccount());

        // Lets the user double-check what they typed before logging in.
        checkShowPassword.setOnCheckedChangeListener((button, isChecked) -> {
            editPassword.setTransformationMethod(isChecked
                    ? HideReturnsTransformationMethod.getInstance()
                    : PasswordTransformationMethod.getInstance());
            editPassword.setSelection(editPassword.getText().length());
        });
    }

    /** Checks the typed credentials against the users table. */
    private void handleLogin() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        long userId = dbHelper.validateUser(username, password);
        if (userId == -1) {
            Toast.makeText(this, "Wrong username or password", Toast.LENGTH_SHORT).show();
        } else {
            openInventory(userId);
        }
    }

    /** Saves a brand new login to the database, then drops the user into the app. */
    private void handleCreateAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();
        String phone = editPhone.getText().toString().trim();

        if (username.isEmpty() || password.length() < 4) {
            Toast.makeText(this, "Enter a username and a password of at least 4 characters",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if (!phone.isEmpty() && !phone.matches(PHONE_PATTERN)) {
            Toast.makeText(this, "That phone number doesn't look right", Toast.LENGTH_SHORT).show();
            return;
        }
        if (dbHelper.userExists(username)) {
            Toast.makeText(this, "That username is already taken", Toast.LENGTH_SHORT).show();
            return;
        }

        long userId = dbHelper.createUser(username, password, phone);
        if (userId == -1) {
            Toast.makeText(this, "Could not create the account, please try again",
                    Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
            openInventory(userId);
        }
    }

    private void openInventory(long userId) {
        Intent intent = new Intent(this, InventoryActivity.class);
        intent.putExtra(EXTRA_USER_ID, userId);
        startActivity(intent);
        finish(); // so the back button doesn't return to the login screen
    }
}
