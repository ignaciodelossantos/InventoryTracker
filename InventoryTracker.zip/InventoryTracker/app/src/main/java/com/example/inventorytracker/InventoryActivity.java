package com.example.inventorytracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Main screen: shows the inventory grid and handles add / edit / delete,
 * search, quick quantity changes, and the low-stock alerts.
 */
public class InventoryActivity extends AppCompatActivity
        implements InventoryAdapter.ItemActionListener {

    /** Alert level given to a new item unless the user types another one. */
    public static final int DEFAULT_LOW_STOCK_LEVEL = 5;

    private static final int MAX_QUANTITY = 999999;
    private static final int MAX_NAME_LENGTH = 40;
    private static final String PHONE_PATTERN = "[+0-9() -]{3,20}";

    private DatabaseHelper dbHelper;
    private InventoryAdapter adapter;
    private TextView textSmsStatus;
    private TextView textSummary;
    private TextView textEmpty;
    private EditText editSearch;
    private long userId;
    private boolean smsGranted;

    // Modern replacement for onRequestPermissionsResult.
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                smsGranted = granted;
                updateSmsStatus();
                if (!granted) {
                    // Everything else keeps working, I just let the user know alerts are off.
                    Toast.makeText(this, "No problem, the app will work without text alerts",
                            Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, -1);
        dbHelper = new DatabaseHelper(this);

        textSmsStatus = findViewById(R.id.textSmsStatus);
        textSummary = findViewById(R.id.textSummary);
        textEmpty = findViewById(R.id.textEmpty);
        editSearch = findViewById(R.id.editSearch);

        GridView grid = findViewById(R.id.gridInventory);
        adapter = new InventoryAdapter(this, new ArrayList<>(), this);
        grid.setAdapter(adapter);
        grid.setEmptyView(textEmpty); // shown automatically when the grid has no items

        findViewById(R.id.buttonAddItem).setOnClickListener(v -> showItemDialog(null));
        findViewById(R.id.buttonAlertPhone).setOnClickListener(v -> showPhoneDialog());
        findViewById(R.id.buttonLogout).setOnClickListener(v -> logOut());

        // Tapping the status line lets the user turn alerts on later if they said no at first.
        textSmsStatus.setOnClickListener(v -> {
            if (!smsGranted) {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        // Filter the grid as the user types in the search box.
        editSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                refreshGrid();
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        refreshGrid();
        checkSmsPermission();
    }

    // ------------------------------------------------------------ permission

    /** Asks for SMS permission the first time, and just records the answer afterwards. */
    private void checkSmsPermission() {
        smsGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        updateSmsStatus();
        if (!smsGranted) {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void updateSmsStatus() {
        textSmsStatus.setText(smsGranted ? R.string.sms_enabled : R.string.sms_disabled);
    }

    // ------------------------------------------------------------- the grid

    /** Reloads the items, applies the search text, and updates the summary line. */
    private void refreshGrid() {
        List<InventoryItem> allItems = dbHelper.getItems(userId);
        String filter = editSearch.getText().toString().trim().toLowerCase(Locale.getDefault());

        List<InventoryItem> shownItems = new ArrayList<>();
        int lowCount = 0;
        for (InventoryItem item : allItems) {
            if (item.isLow()) {
                lowCount++;
            }
            if (filter.isEmpty()
                    || item.getName().toLowerCase(Locale.getDefault()).contains(filter)) {
                shownItems.add(item);
            }
        }

        textEmpty.setText(allItems.isEmpty() ? R.string.empty_inventory : R.string.empty_search);
        textSummary.setText("Items: " + allItems.size() + "   Low stock: " + lowCount);
        adapter.setItems(shownItems);
    }

    // ------------------------------------------------------------- CRUD UI

    /** Shows the add/edit dialog. Pass null to add a new item, or an item to edit it. */
    private void showItemDialog(InventoryItem existing) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_item, null);
        EditText editName = dialogView.findViewById(R.id.editItemName);
        EditText editQuantity = dialogView.findViewById(R.id.editItemQuantity);
        EditText editThreshold = dialogView.findViewById(R.id.editItemThreshold);

        if (existing != null) {
            editName.setText(existing.getName());
            editQuantity.setText(String.valueOf(existing.getQuantity()));
            editThreshold.setText(String.valueOf(existing.getLowThreshold()));
        } else {
            editThreshold.setText(String.valueOf(DEFAULT_LOW_STOCK_LEVEL));
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Add Item" : "Edit Item")
                .setView(dialogView)
                .setPositiveButton("Save", null) // set below so bad input doesn't close the dialog
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(d ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    boolean saved = saveItem(existing,
                            editName.getText().toString().trim(),
                            editQuantity.getText().toString().trim(),
                            editThreshold.getText().toString().trim());
                    if (saved) {
                        dialog.dismiss();
                    }
                }));
        dialog.show();
    }

    /** Validates the form and writes to the database. Returns true if it was saved. */
    private boolean saveItem(InventoryItem existing, String name,
                             String quantityText, String thresholdText) {
        if (name.isEmpty() || quantityText.isEmpty()) {
            showToast("Please fill in the name and quantity");
            return false;
        }
        if (name.length() > MAX_NAME_LENGTH) {
            showToast("Item names can be up to " + MAX_NAME_LENGTH + " characters");
            return false;
        }

        long excludeId = (existing == null) ? -1 : existing.getId();
        if (dbHelper.itemNameExists(userId, name, excludeId)) {
            showToast("You already have an item called " + name);
            return false;
        }

        int quantity;
        int threshold;
        try {
            quantity = Integer.parseInt(quantityText);
            threshold = thresholdText.isEmpty()
                    ? DEFAULT_LOW_STOCK_LEVEL : Integer.parseInt(thresholdText);
        } catch (NumberFormatException e) {
            showToast("Numbers must be whole numbers");
            return false;
        }
        if (quantity > MAX_QUANTITY || threshold > MAX_QUANTITY) {
            showToast("Numbers can't be bigger than " + MAX_QUANTITY);
            return false;
        }

        // -1 means "brand new item" so the alert check knows there was no earlier amount.
        int oldQuantity = (existing == null) ? -1 : existing.getQuantity();
        if (existing == null) {
            dbHelper.addItem(userId, name, quantity, threshold);
        } else {
            dbHelper.updateItem(existing.getId(), name, quantity, threshold);
        }

        refreshGrid();
        checkLowStock(name, quantity, threshold, oldQuantity);
        return true;
    }

    @Override
    public void onEdit(InventoryItem item) {
        showItemDialog(item);
    }

    @Override
    public void onDelete(InventoryItem item) {
        // Ask first so a stray tap doesn't wipe an item.
        new AlertDialog.Builder(this)
                .setTitle("Delete " + item.getName() + "?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    dbHelper.deleteItem(item.getId());
                    refreshGrid();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Handles the + and - buttons on a card. */
    @Override
    public void onAdjustQuantity(InventoryItem item, int change) {
        int newQuantity = item.getQuantity() + change;
        if (newQuantity < 0) {
            showToast("Quantity can't go below zero");
            return;
        }
        if (newQuantity > MAX_QUANTITY) {
            showToast("Numbers can't be bigger than " + MAX_QUANTITY);
            return;
        }

        dbHelper.updateQuantity(item.getId(), newQuantity);
        refreshGrid();
        checkLowStock(item.getName(), newQuantity, item.getLowThreshold(), item.getQuantity());
    }

    // ------------------------------------------------------------ alert phone

    /** Lets the user set or change the number that low-stock texts go to. */
    private void showPhoneDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_phone, null);
        EditText editPhone = dialogView.findViewById(R.id.editPhoneDialog);
        editPhone.setText(dbHelper.getPhone(userId));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Alert phone number")
                .setView(dialogView)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(d ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    String phone = editPhone.getText().toString().trim();
                    if (!phone.isEmpty() && !phone.matches(PHONE_PATTERN)) {
                        showToast("That phone number doesn't look right");
                        return;
                    }
                    dbHelper.updatePhone(userId, phone);
                    showToast("Alert phone saved");
                    dialog.dismiss();
                }));
        dialog.show();
    }

    private void logOut() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    // ------------------------------------------------------------------ SMS

    /**
     * Warns the user when an item gets low. The on-screen message always appears;
     * the text message only goes out if SMS permission was granted.
     * Only fires when the stock went down, so raising a quantity doesn't spam anyone.
     */
    private void checkLowStock(String itemName, int newQuantity, int threshold, int oldQuantity) {
        boolean isLow = newQuantity <= threshold;
        boolean stockWentDown = (oldQuantity < 0) || (newQuantity < oldQuantity);
        if (!isLow || !stockWentDown) {
            return;
        }

        showToast(itemName + " is low on stock (" + newQuantity + " left)");
        if (!smsGranted) {
            return;
        }

        String phone = dbHelper.getPhone(userId);
        if (phone.isEmpty()) {
            showToast("Add an alert phone number to get text messages");
            return;
        }

        boolean sent = SmsHelper.sendLowStockAlert(this, phone, itemName, newQuantity);
        showToast(sent ? "Low stock text sent" : "Couldn't send the text alert");
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
