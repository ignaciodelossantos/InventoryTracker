package com.example.inventorytracker;

import android.content.Context;
import android.os.Build;
import android.telephony.SmsManager;

/**
 * Keeps the SMS code out of the activity. Callers must already have the
 * SEND_SMS permission before using this.
 */
public final class SmsHelper {

    private SmsHelper() {
        // Utility class, nothing to instantiate.
    }

    /** Sends one low-stock text. Returns true if it was handed to the system. */
    public static boolean sendLowStockAlert(Context context, String phone,
                                            String itemName, int quantity) {
        String message = "Low stock alert: " + itemName + " is down to " + quantity + ".";
        try {
            // Android 12 (API 31) changed how SmsManager is obtained.
            SmsManager smsManager = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                    ? context.getSystemService(SmsManager.class)
                    : SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, message, null, null);
            return true;
        } catch (Exception e) {
            // A bad number or a missing SIM shouldn't crash the app.
            return false;
        }
    }
}
