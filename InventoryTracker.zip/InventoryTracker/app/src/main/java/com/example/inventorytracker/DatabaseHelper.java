package com.example.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles every SQLite call in the app: user accounts and inventory items.
 * Keeping all the SQL in one class means the activities never touch raw queries.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory.db";
    private static final int DB_VERSION = 2; // v2 added the per-item alert level

    // users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";
    private static final String COL_SALT = "salt";
    private static final String COL_PHONE = "phone";

    // inventory table
    private static final String TABLE_ITEMS = "inventory";
    private static final String COL_ITEM_ID = "id";
    private static final String COL_ITEM_USER_ID = "user_id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_ITEM_QUANTITY = "quantity";
    private static final String COL_ITEM_THRESHOLD = "low_threshold";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL, "
                + COL_SALT + " TEXT NOT NULL, "
                + COL_PHONE + " TEXT)");

        // Each item belongs to a user so two people on one phone don't share stock lists.
        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " ("
                + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_USER_ID + " INTEGER NOT NULL, "
                + COL_ITEM_NAME + " TEXT NOT NULL, "
                + COL_ITEM_QUANTITY + " INTEGER NOT NULL, "
                + COL_ITEM_THRESHOLD + " INTEGER NOT NULL DEFAULT 5, "
                + "FOREIGN KEY(" + COL_ITEM_USER_ID + ") REFERENCES "
                + TABLE_USERS + "(" + COL_USER_ID + "))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Keeps data from earlier installs: just add the new column with the old default of 5.
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_ITEMS + " ADD COLUMN "
                    + COL_ITEM_THRESHOLD + " INTEGER NOT NULL DEFAULT 5");
        }
    }

    // ---------------------------------------------------------------- users

    /** Returns true if the username is already taken. */
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + " = ?", new String[]{username}, null, null, null)) {
            return c.moveToFirst();
        }
    }

    /** Creates a new account. Returns the new user id, or -1 if something went wrong. */
    public long createUser(String username, String password, String phone) {
        String salt = generateSalt();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_SALT, salt);
        values.put(COL_PASSWORD_HASH, hashPassword(password, salt));
        values.put(COL_PHONE, phone);
        return getWritableDatabase().insert(TABLE_USERS, null, values);
    }

    /** Checks the login. Returns the user id if it matches, otherwise -1. */
    public long validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.query(TABLE_USERS,
                new String[]{COL_USER_ID, COL_PASSWORD_HASH, COL_SALT},
                COL_USERNAME + " = ?", new String[]{username}, null, null, null)) {
            if (!c.moveToFirst()) {
                return -1;
            }
            String storedHash = c.getString(c.getColumnIndexOrThrow(COL_PASSWORD_HASH));
            String salt = c.getString(c.getColumnIndexOrThrow(COL_SALT));
            if (storedHash.equals(hashPassword(password, salt))) {
                return c.getLong(c.getColumnIndexOrThrow(COL_USER_ID));
            }
            return -1;
        }
    }

    /** Gets the phone number the user saved for SMS alerts (may be empty). */
    public String getPhone(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.query(TABLE_USERS, new String[]{COL_PHONE},
                COL_USER_ID + " = ?", new String[]{String.valueOf(userId)},
                null, null, null)) {
            if (c.moveToFirst() && !c.isNull(0)) {
                return c.getString(0);
            }
            return "";
        }
    }

    /** Lets the user change the alert phone number after the account exists. */
    public boolean updatePhone(long userId, String phone) {
        ContentValues values = new ContentValues();
        values.put(COL_PHONE, phone);
        int rows = getWritableDatabase().update(TABLE_USERS, values,
                COL_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        return rows > 0;
    }

    // ---------------------------------------------------------------- items

    /** Create: adds a new item for this user. Returns the new row id. */
    public long addItem(long userId, String name, int quantity, int lowThreshold) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_USER_ID, userId);
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QUANTITY, quantity);
        values.put(COL_ITEM_THRESHOLD, lowThreshold);
        return getWritableDatabase().insert(TABLE_ITEMS, null, values);
    }

    /** Read: returns every item for this user, sorted by name. */
    public List<InventoryItem> getItems(long userId) {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.query(TABLE_ITEMS,
                new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_ITEM_QUANTITY, COL_ITEM_THRESHOLD},
                COL_ITEM_USER_ID + " = ?", new String[]{String.valueOf(userId)},
                null, null, COL_ITEM_NAME + " COLLATE NOCASE")) {
            while (c.moveToNext()) {
                items.add(new InventoryItem(c.getLong(0), c.getString(1),
                        c.getInt(2), c.getInt(3)));
            }
        }
        return items;
    }

    /** True if this user already has an item with that name (ignoring one id, for edits). */
    public boolean itemNameExists(long userId, String name, long excludeItemId) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.query(TABLE_ITEMS, new String[]{COL_ITEM_ID},
                COL_ITEM_USER_ID + " = ? AND " + COL_ITEM_NAME + " = ? COLLATE NOCASE AND "
                        + COL_ITEM_ID + " != ?",
                new String[]{String.valueOf(userId), name, String.valueOf(excludeItemId)},
                null, null, null)) {
            return c.moveToFirst();
        }
    }

    /** Update: changes the name, quantity and alert level of one item. */
    public boolean updateItem(long itemId, String name, int quantity, int lowThreshold) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QUANTITY, quantity);
        values.put(COL_ITEM_THRESHOLD, lowThreshold);
        int rows = getWritableDatabase().update(TABLE_ITEMS, values,
                COL_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }

    /** Update: used by the quick + / - buttons, only touches the quantity. */
    public boolean updateQuantity(long itemId, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_QUANTITY, quantity);
        int rows = getWritableDatabase().update(TABLE_ITEMS, values,
                COL_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }

    /** Delete: removes one item. */
    public boolean deleteItem(long itemId) {
        int rows = getWritableDatabase().delete(TABLE_ITEMS,
                COL_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }

    // -------------------------------------------------------------- helpers

    /** Random salt so two users with the same password don't get the same hash. */
    private String generateSalt() {
        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        return Base64.encodeToString(bytes, Base64.NO_WRAP);
    }

    /** SHA-256 of salt + password. I never store the plain password. */
    private String hashPassword(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest((salt + password).getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(hash, Base64.NO_WRAP);
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is guaranteed on every Android device, so this shouldn't happen.
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }
}
