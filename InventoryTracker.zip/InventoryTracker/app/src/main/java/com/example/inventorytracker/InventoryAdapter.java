package com.example.inventorytracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

/**
 * Feeds the inventory items into the GridView, one card per item.
 */
public class InventoryAdapter extends BaseAdapter {

    // Card colors: normal items are light blue, low-stock items are light red.
    private static final int COLOR_NORMAL = 0xFFE3F2FD;
    private static final int COLOR_LOW = 0xFFFFEBEE;
    private static final int TEXT_LOW = 0xFFC62828;
    private static final int TEXT_NORMAL = 0xFF000000;

    /** Lets the activity decide what happens when a card's buttons are tapped. */
    public interface ItemActionListener {
        void onEdit(InventoryItem item);
        void onDelete(InventoryItem item);
        void onAdjustQuantity(InventoryItem item, int change);
    }

    private final Context context;
    private final ItemActionListener listener;
    private List<InventoryItem> items;

    public InventoryAdapter(Context context, List<InventoryItem> items, ItemActionListener listener) {
        this.context = context;
        this.items = items;
        this.listener = listener;
    }

    /** Swaps in a fresh list after the database or the search box changes. */
    public void setItems(List<InventoryItem> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return items.get(position).getId(); }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        }

        InventoryItem item = items.get(position);
        TextView textName = convertView.findViewById(R.id.textItemName);
        TextView textQuantity = convertView.findViewById(R.id.textItemQuantity);
        TextView textThreshold = convertView.findViewById(R.id.textItemThreshold);

        textName.setText(item.getName());
        textThreshold.setText("Alert at: " + item.getLowThreshold() + " or fewer");

        // Low-stock cards get a red tint and a label so they're easy to spot.
        boolean isLow = item.isLow();
        textQuantity.setText(isLow ? "Qty: " + item.getQuantity() + "  (LOW)"
                                   : "Qty: " + item.getQuantity());
        textQuantity.setTextColor(isLow ? TEXT_LOW : TEXT_NORMAL);
        convertView.setBackgroundColor(isLow ? COLOR_LOW : COLOR_NORMAL);

        Button buttonDecrease = convertView.findViewById(R.id.buttonDecrease);
        Button buttonIncrease = convertView.findViewById(R.id.buttonIncrease);
        Button buttonEdit = convertView.findViewById(R.id.buttonEdit);
        Button buttonDelete = convertView.findViewById(R.id.buttonDelete);

        buttonDecrease.setOnClickListener(v -> listener.onAdjustQuantity(item, -1));
        buttonIncrease.setOnClickListener(v -> listener.onAdjustQuantity(item, 1));
        buttonEdit.setOnClickListener(v -> listener.onEdit(item));
        buttonDelete.setOnClickListener(v -> listener.onDelete(item));
        return convertView;
    }
}
